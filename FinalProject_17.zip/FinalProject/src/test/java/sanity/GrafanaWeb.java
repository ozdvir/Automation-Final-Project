package sanity;

import com.google.common.util.concurrent.Uninterruptibles;
import extensions.UIActions;
import extensions.Verification;
import org.testng.annotations.Test;
import utilities.CommonOps;
import workflows.WebFlows;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class GrafanaWeb extends CommonOps {


    @Test
    public void test01_VerifyHeader()
    {
        WebFlows.login("admin","admin");
        Verification.verifyTextInElement(grafanaMain.head_Dashboard , "Home Dashboard");
    }


    @Test
    public void test02_VerifyDefaultUsers()
    {
        UIActions.mouseHover(grafanaLeftMenu.btn_server, grafanaServerAdminMenu.link_users);
        Verification.numberOfElements(grafanaServerAdminMain.rows,1);
    }

    @Test
    public void test03_VerifyNewUser()
    {

        UIActions.mouseHover(grafanaLeftMenu.btn_server, grafanaServerAdminMenu.link_users);
        WebFlows.createNewUser("oz","ozdvir@gmail.com","ozdvir","1234");
        Verification.numberOfElements(grafanaServerAdminMain.rows,2);
    }

    @Test
    public void test04_VerifyDeletionUser()
    {
        UIActions.mouseHover(grafanaLeftMenu.btn_server, grafanaServerAdminMenu.link_users);
        WebFlows.deleteLastUser();
        Verification.numberOfElements(grafanaServerAdminMain.rows,1);
    }

    @Test
    public void test05_VerifyProgressSteps()
    {
        Verification.visibilityOfElements(grafanaMain.list_progressSteps);
    }


}
